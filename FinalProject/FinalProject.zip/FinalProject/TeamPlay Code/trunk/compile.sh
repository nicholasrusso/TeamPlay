javac -cp '.:classes/sqlite-jdbc-3.8.11.2.jar' SQLiteExample.java
