sqlite3 ../data/test.db < populateDB.sql
