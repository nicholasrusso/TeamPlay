sqlite3 ../data/test.db < createDB.sql
