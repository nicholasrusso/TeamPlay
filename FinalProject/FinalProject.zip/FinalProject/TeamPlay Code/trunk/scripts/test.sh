sqlite3 ../data/test.db < testSelection.sql
