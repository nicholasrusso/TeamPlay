select * from proplayer
where number = 10;
