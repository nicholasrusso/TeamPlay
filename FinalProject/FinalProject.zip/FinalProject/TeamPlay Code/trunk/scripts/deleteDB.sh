rm -fv ../data/test.db
