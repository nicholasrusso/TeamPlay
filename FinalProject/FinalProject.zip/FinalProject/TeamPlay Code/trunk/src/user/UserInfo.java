package user;

public class UserInfo {

	private UserInfo() {
		// Static class
	}
	
}
