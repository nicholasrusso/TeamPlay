package soccerplayer;


public interface SoccerPlayer
{
       
    public String getName() ;
    
    public String getTeam() ;
    
    @Override
    public String toString() ;
    
    public int score() ;
    
    public int getScore() ;
    
    public String getPosition();
    
}
