The data directory should hold persistent data.
This includes the SQLite db file. To create the test.db file, run
bin/createDB.sh and bin/populateDB.sh
